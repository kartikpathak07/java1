package Q4;

public class Printer extends Thread
{
	Storage t1;
	public void run()
	{
		System.out.println("Count is : "+t1.getCount());
	}
}

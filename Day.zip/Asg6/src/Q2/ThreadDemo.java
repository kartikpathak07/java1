package Q2;

public class ThreadDemo 
{

	public static void main(String[] args) 
	{
		// TODO Auto-generated method stub
		Thread th1=new Thread(new MyThread());
		Thread th2=new Thread(new MyThread());
		Thread th3=new Thread(new MyThread());
		th1.start();
		th2.start();
		th3.start();
	}
}

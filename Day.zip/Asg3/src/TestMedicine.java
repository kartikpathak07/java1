import java.util.Date;
import java.util.Random;
import java.util.Scanner;

public class TestMedicine 
{
	@SuppressWarnings("deprecation")
	public static void main(String[] args) 
	{
		// TODO Auto-generated method stub
		Scanner sc=new Scanner(System.in);
		Random r=new Random();
		int n;
		System.out.println("Enter the number of items to be entered : ");
		int no_of_items=sc.nextInt();
		Medicine marr[]=new Medicine[no_of_items];
		for (int i = 0; i < marr.length; i++) 
		{
			n=r.nextInt(3)+1;
			if(n==1)
			{
				marr[i]=new Tablet();
				Date d=new Date();
				marr[i].setPrice(sc.nextInt());
				d.setDate(sc.nextInt());
				d.setMonth((sc.nextInt())-1);
				d.setYear((sc.nextInt())-1900);
				marr[i].setExdate(d);
				marr[i].displayLabel();
			}
			else if(n==2)
			{
				marr[i]=new Syrup();
				Date d=new Date();
				marr[i].setPrice(sc.nextInt());
				d.setDate(sc.nextInt());
				d.setMonth((sc.nextInt())-1);
				d.setYear((sc.nextInt())-1900);
				marr[i].setExdate(d);
				marr[i].displayLabel();
			}
			else
			{
				marr[i]=new Ointment();
				Date d=new Date();
				marr[i].setPrice(sc.nextInt());
				d.setDate(sc.nextInt());
				d.setMonth((sc.nextInt())-1);
				d.setYear((sc.nextInt())-1900);
				marr[i].setExdate(d);
				marr[i].displayLabel();
			}
		}
		sc.close();
	}

}


public class Tablet extends Medicine
{

	@Override
	void displayLabel() 
	{
		// TODO Auto-generated method stub
		System.out.println("Store in a cool and dry place");
		
	}

}

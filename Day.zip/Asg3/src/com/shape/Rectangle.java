package com.shape;

import java.util.Scanner;

public class Rectangle implements Polygon
{
	Scanner sc=new Scanner(System.in);
	float length,breadth;
	float res,ans;

	@Override
	public void calcArea() 
	{
		// TODO Auto-generated method stub
		System.out.print("Enter the length of rectangle : ");
		length=sc.nextFloat();
		System.out.print("Enter the breadth of rectangle : ");
		breadth=sc.nextFloat();
		res=length*breadth;
	}

	@Override
	public void calcPeri() 
	{
		// TODO Auto-generated method stub
		ans=2*(length+breadth);
	}

	@Override
	public String toString() {
		return "Rectangle [Area=" + res + ", Perimeter=" + ans + "]";
	}
}

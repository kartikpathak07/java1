package com.shape;

public interface Polygon 
{
	void calcArea( );
	void calcPeri( );
}

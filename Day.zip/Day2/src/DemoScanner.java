import java.util.Scanner;


public class DemoScanner
{

	public static void main(String[] args)
	{
		// TODO Auto-generated method stub
		Scanner sc=new Scanner(System.in);
		int i;
		System.out.println("Enter a number");
		i=sc.nextInt();
		System.out.println("You have entered : "+i);
		sc.close();
	}

}

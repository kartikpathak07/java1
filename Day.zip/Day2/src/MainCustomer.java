
public class MainCustomer 
{

	@SuppressWarnings("unused")
	public static void main(String[] args) 
	{
		// TODO Auto-generated method stub
		Customer c1=new Customer("C101", "Ibrahimovic", 956235853);
		Customer c2=new Customer("C102", "Rooney", 864563187);
		Customer c3=new Customer("C103", "Pogba", 864523156);
		Customer c4=new Customer("C104", "Mkhitaryan", 786532549);
		
		Customer.showcount();
		
	}
}


public class Student 
{
	
	//Attributes of student class
	private int rollno;
	private String sname;
	
	//Default constructor
	public Student() 
	{
		System.out.println("In default constructor...........");
	}
	
	//Parameterized constructor
	public Student(int roll, String name) 
	{
		System.out.println("In parameterized constructor...........");
		rollno = roll;
		sname = name;
	}

	//Getter methods for attributes
	public int getRollno() 
	{
		return rollno;
	}
	
	public String getSname() 
	{
		return sname;
	}
	
	//Method to display output
	public void showStudent()
	{
		System.out.println("Roll No : "+rollno);
		System.out.println("Name : "+sname);
	}
	
}

import java.io.File;
import java.io.IOException;


public class DemoFile
{

	public static void main(String[] args) 
	{
		// TODO Auto-generated method stub
		File f=new File("data.txt");
		if(f.exists())
		{
			System.out.println("File exists");
		}
		else
		{
			try 
			{
				if (f.createNewFile())
				{
					System.out.println("File created");
				}
				else
				{
					System.out.println("File already exists");
				}
			}
			catch (IOException e) 
			{
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}

	}

}

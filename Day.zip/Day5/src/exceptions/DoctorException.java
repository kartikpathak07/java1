package exceptions;

@SuppressWarnings("serial")
public class DoctorException extends Exception 
{
	//1. toString
	/*@Override
	public String toString() {
		System.err.println("Plz enter a degree");
	}*/


	//2. default constructor
	public DoctorException() 
	{
		System.out.println("DoctorException.DoctorException()");
	}

	//3. parameterized constructor taking String argument

}

package Q1;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Scanner;


public class CopyFile
{

	public static void main(String[] args) 
	{
		// TODO Auto-generated method stub
		Scanner sc=new Scanner(System.in);
		try 
		{
			FileReader fr=new FileReader("Q1src.txt");
			File f=new File("Q1dest1.txt");
			if(f.exists())
			{
				System.out.println("File exists! Do you want to overite file? (Y/N)");
				char c=sc.next().charAt(0);
				if(c=='Y')
				{
					System.out.println("Copying file");
					FileWriter fw=new FileWriter(f);
					int ch;
					while((ch=fr.read())!=-1)
					{
						fw.write(ch);
					}
					fr.close();
					fw.close();
					System.out.println("File copied successfully!!!");
				}
				else if(c=='N')
				{
					fr.close();
				}
				else
				{
					System.out.println("Enter valid input");
				}
			}
			else
			{
				System.out.println("Invalid file");
				if (f.createNewFile())
				{
					System.out.println("File created");
					System.out.println("Copying file");
					FileWriter fw=new FileWriter(f);
					int ch;
					while((ch=fr.read())!=-1)
					{
						fw.write(ch);
					}
					fr.close();
					fw.close();
					System.out.println("File copied successfully!!!");
				}
			}
		}
		catch (FileNotFoundException e)
		{
			System.out.println("File to be copied does not exist!!");
		}
		catch (IOException e)
		{
			e.printStackTrace();
		}
	}
}

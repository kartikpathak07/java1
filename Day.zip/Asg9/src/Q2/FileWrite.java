package Q2;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Scanner;

public class FileWrite
{

	public static void main(String[] args)
	{
		// TODO Auto-generated method stub
		Scanner sc=new Scanner(System.in);
		String str[]=new String[5];
		System.out.println("Enter 5 lines");
		for (int i=0;i<str.length;i++) 
		{
			str[i]=sc.next();
		}
		File f=new File("letter.txt");
		try
		{
			FileWriter fw=new FileWriter(f);
			for (int i=0;i<str.length;i++)
			{
				fw.write(str[i]);
				fw.append("\n");
			}
			fw.close();
		}
		catch (IOException e)
		{
			e.printStackTrace();
		}
			FileReader fr;
			try {
				fr = new FileReader(f);
				int ch;
				while((ch=fr.read())!=-1)
				{
					System.out.print((char) ch);
				}
				fr.close();
			} 
			catch (FileNotFoundException e)
			{
				e.printStackTrace();
			} 
			catch (IOException e) 
			{
				e.printStackTrace();
			}
			System.out.println(f.getTotalSpace());
			System.out.println(f.length());
			f.delete();
			if(f.exists())
			{
				System.out.println("Gandla");
			}
	}

}

/*Mkhitaryan
Rooney
DeGea
Pogba
Zlatan*/

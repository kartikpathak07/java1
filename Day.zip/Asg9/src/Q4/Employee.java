package Q4;

public class Employee 
{
	private int empNo;
	private String empName;
	private int empBasic;
	
	public Employee(int empNo, String empName, int empBasic) 
	{
		this.empNo = empNo;
		this.empName = empName;	
		this.empBasic = empBasic;
	}

	@Override
	public String toString() 
	{
		return empNo+","+empName+ ","+empBasic;
	}
}

import java.util.Scanner;


public class EmpMain 
{

	public static void main(String[] args) 
	{
		// TODO Auto-generated method stub
		Scanner sc=new Scanner(System.in);
		
		//Create an arroy of emp type
		System.out.println("How may employees are present : ");
		int no_of_emp=sc.nextInt();
		Emp earr[]=new Emp[no_of_emp];
		for (int i = 0; i < earr.length; i++) 
		{
			earr[i]=new Emp();
			System.out.println("Enter employee ID of employee "+(i+1));
			earr[i].setEid(sc.nextInt());
			System.out.println("Enter employee name of employee "+(i+1));
			earr[i].setEname(sc.next());
		}

	}

}

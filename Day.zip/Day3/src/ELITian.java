import java.util.Date;


public class ELITian extends Associate 
{
	private int groupID;
	private String mappedIBU;

	public ELITian(int id, String name, Date joinDate, int groupID,
			String mappedIBU) 
	{
		super(id, name, joinDate);
		this.groupID = groupID;
		this.mappedIBU = mappedIBU;
	}

	@Override
	public String toString() {
		return "ELITian [Id : " + getId() + ", Name : " + getName()
				+ ", JoinDate : " + getJoinDate() + ", groupID : "+ this.groupID + ", Mapped IBU : " + this.mappedIBU +"]";
	}


	
	
	
	
	
	
}

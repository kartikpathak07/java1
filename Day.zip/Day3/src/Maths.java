
public class Maths 
{
	int add(int n1,int n2)
	{
		return (n1+n2);
	}
	
	double add(double n1,int n2)
	{
		return (n1+n2);
	}
	
	float add(int n1,float n2)
	{
		return (n1+n2);
	}
	
	public static void main(String[] args) 
	{
		// TODO Auto-generated method stub
		Maths m=new Maths();
		System.out.println(m.add(5,2));
		System.out.println(m.add(23.12,7));
		System.out.println(m.add(7,12.7f));

	}

}

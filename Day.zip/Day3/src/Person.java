
public abstract class Person 
{
	String fname;
	String lname;
	String address;
	
	public Person(String fname, String lname, String address) 
	{
		this.fname = fname;
		this.lname = lname;
		this.address = address;
	}

	@Override
	public String toString() {
		return "Person [fname=" + fname + ", lname=" + lname + ", address="
				+ address + "]";
	}
	
	public abstract void showDetails();

}

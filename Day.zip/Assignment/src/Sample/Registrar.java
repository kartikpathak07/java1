package Sample;

public class Registrar
{
	public static boolean registerStudent(Student s) 
	{
		System.out.println("Registrar has sent your details to validator.........please wait.............");
		if(Validator.validateStudent(s))
		{
			return true;
		}
		else
		{
			return false;
		}		
	}
}

package Sample;

public class Validator 
{
	public static boolean validateStudent(Student s) 
	{
		System.out.println("Validator validating your details "+s.getName()+", please wait...................");
		if(s.getPreviousMarks()>80)
		{
			return true;
		}
		else
		{
			return false;
		}

	}

}

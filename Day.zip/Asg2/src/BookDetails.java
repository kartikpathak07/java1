import java.util.Scanner;


@SuppressWarnings("unused")
public class BookDetails 
{
	public static void main(String[] args) 
	{
		// TODO Auto-generated method stub
		/*Book b1=new Book();
		b1.setBookNo(101);
		b1.setTitle("Leading");
		b1.setPrice(500);
		b1.setAuthor("Sir Alex Fergusson");
		b1.showBookGet();*/
		
		/*Book b1=new Book(101,"MUFC","Sir Alex Fergusson",1000);
		Book b2=new Book(102,"RMFC","Zinadne Zidane",500);
		Book b3=new Book(103,"CFC","Jose Mourinho",750);*/
		/*b1.showBookCons();
		System.out.println(b1.toString());*/
		
		/*Scanner sc=new Scanner(System.in);
		
		Book bk[]=new Book[3];
		for(int i=0;i<bk.length;i++)
		{
			bk[i]=new Book();
			System.out.println("Enter book no. for book "+(i+1));
			Scanner bk1=new Scanner(System.in);
			int bkno=bk1.nextInt();
			System.out.println("Enter book name for book "+(i+1));
			Scanner bk2=new Scanner(System.in);
			String bkn=bk2.useDelimiter("\n").next();
			System.out.println("Enter author name for book "+(i+1));
			Scanner bk4=new Scanner(System.in);
			String ath=bk4.nextLine();
			System.out.println("Enter price for book "+(i+1));
			Scanner bk3=new Scanner(System.in);
			float pr=bk3.nextFloat();
			bk[i].setBookNo(bkno);
			bk[i].setTitle(bkn);
			bk[i].setAuthor(ath);
			bk[i].setPrice(pr);
			bk[i].setBookCount(bk[i].getBookCount());
		}
		
		for(int i=0;i<bk.length;i++)
		{
			bk[i].showBookGet();
		}
		
		System.out.println("Enter the book ID for search : ");
		int ch=sc.nextInt();
		int j=0;
		for(j=0;j<Book.getBookCount();j++)
		{
			if (bk[j].getBookNo()==ch)
			{
				System.out.println("Book found");
				break;
			}
		}
		if(j==bk.length)
		{
			System.out.println("Book not found!!");
		}
		sc.close();*/
		
		EngineeringBook eb1=new EngineeringBook();
		eb1.setBookNo(107);
		eb1.setCategory("E&Tc");
		eb1.setTitle("ITCT");
		eb1.setAuthor("abcd");
		eb1.setPrice(250);
		eb1.DisplayGet();
		
	}

}

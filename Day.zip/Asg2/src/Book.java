
public class Book 
{
	static
	{
		@SuppressWarnings("unused")
		int bookCount=0;
	}
	private int bookNo;
	private String title;
	private String author;
	private float price;
	private static  int bookCount;
	
	public Book(int bookNo, String title, String author, float price) {
		super();
		this.bookNo = bookNo;
		if(title.length()>4)
		{
			this.title = title;
		}
		else
		{
			System.err.println("Name should have at least 4 characters");
		}
		this.author = author;
		if(price>0&&price<=5000)
		{
			this.price = price;
		}
		else
		{
			System.err.println("Price should be between 1 to 5000");
		}
	}	

	public Book() {
		// TODO Auto-generated constructor stub
	}

	public void showBookCons() 
	{
		System.out.println("Book no. : "+bookNo);
		System.out.println("Book Name : "+title);
		System.out.println("Price : "+price);
		System.out.println("Author : "+author);
	}

	public int getBookNo() {
		return bookNo;
	}
	public void setBookNo(int bookNo) {
		this.bookNo = bookNo;
	}
	public String getTitle() {
		return title;
	}
	public void setTitle(String title) {
		this.title = title;
	}
	public String getAuthor() {
		return author;
	}
	public void setAuthor(String author) {
		this.author = author;
	}
	public float getPrice() {
		return price;
	}
	public void setPrice(float price) {
		this.price = price;
	}

	public static int getBookCount() {
		return bookCount;
	}
	public static void setBookCount(int bookCount) {
		Book.bookCount = bookCount+1;
	}
	
	
	@Override
	public String toString() {
		return "Book [bookNo=" + bookNo + ", title=" + title + ", author="
				+ author + ", price=" + price + "]";
	}

	public void showBookGet() 
	{
		System.out.println("Book no. : "+bookNo);
		System.out.println("Book Name : "+title);
		System.out.println("Price : "+price);
		System.out.println("Author : "+author);
		System.out.println("Bookcount : "+bookCount);
	}

}

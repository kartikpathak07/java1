package D7;

public class ItalianPizza extends Pizza
{

	public ItalianPizza(String type, String name, String size, String toppings) 
	{
		super(type, name, size, toppings);
	}

	@Override
	int calculateCost()
	{
		if(type.equalsIgnoreCase("veg"))
		{
			if(size.equalsIgnoreCase("small"))
			{
				if(toppings.equalsIgnoreCase("no"))
				{
					return 200;
				}
				else
				{
					return 230;
				}
			}
			else if(size.equalsIgnoreCase("medium"))
			{
				if(toppings.equalsIgnoreCase("no"))
				{
					return 350;
				}
				else
				{
					return 380;
				}
			}
			else
				return 0;
		}
		else if(type.equalsIgnoreCase("nonveg"))
		{
			if(size.equalsIgnoreCase("small"))
			{
				if(toppings.equalsIgnoreCase("no"))
				{
					return 270;
				}
				else
				{
					return 300;
				}
			}
			else if(size.equalsIgnoreCase("medium"))
			{
				if(toppings.equalsIgnoreCase("no"))
				{
					return 420;
				}
				else
				{
					return 450;
				}
			}
			else
				return 0;
		}
		else
		return 0;
	}

	@Override
	public String toString()
	{
		return "Italian pizza details are : "+type+" "+name+" of size "+size+" pizza with "+toppings+" toppings which takes "
				+timeForPreparation+" min for preparation and costing "+costOfPizza+"\n";
	}
}

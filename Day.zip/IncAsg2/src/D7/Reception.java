package D7;

import java.util.Date;
import java.util.Scanner;

public class Reception 
{
	static int billno=0;

	public static void main(String[] args)
	{
		Scanner sc=new Scanner(System.in);
		boolean flag=true;
		Reception r=new Reception();
		History h=new History();
		System.out.println("1. Create bills");
		System.out.println("2. Save to File");
		System.out.println("3. Retrieve from file");
		System.out.println("4. Exit");
		
		while(flag==true)
		{
			System.out.println("Enter your choice : ");
			int choice=sc.nextInt();
			switch(choice)
			{

			case 1:
			{
				System.out.println("Enter number of bills : ");
				int bills=sc.nextInt();
				Bill b[]=new Bill[bills];
				for (int i=0;i<b.length; i++) 
				{
					b[i]=new Bill();
					b[i].setBillNo(++billno);
					Date d=new Date();
					d.setDate(27);
					d.setMonth(4-1);
					d.setYear(2017-1900);
					System.out.println("Enter name of customer : ");
					b[i].setCustName(sc.next());
					b[i].setDate(d);
					b[i].setTotal(0);
					System.out.print("Enter the number of orders : ");
					int n=sc.nextInt();
					Pizza p[]=new Pizza[n];
					for (int k=0;k<p.length;k++)
					{
						System.out.print("Enter the Italian/Mexican pizza : ");
						String name=sc.next();
						if(name.equalsIgnoreCase("Italian"))
						{
							System.out.print("Enter veg/nonveg pizza : ");
							String type=sc.next();
							System.out.print("Enter size of pizza : ");
							String size=sc.next();
							System.out.print("Enter toppings : ");
							String toppings=sc.next();
							p[k]=new ItalianPizza(type, name, size, toppings);
						}
						else if(name.equalsIgnoreCase("Mexican"))
						{
							System.out.print("Enter veg/nonveg pizza : ");
							String type=sc.next();
							System.out.print("Enter size of pizza : ");
							String size=sc.next();
							System.out.print("Enter toppings : ");
							String toppings=sc.next();
							p[k]=new MexicanPizza(type, name, size, toppings);
						}
						else
						{
							System.out.println("Inavlid name");
						}
					}				
					for (int j=0;j<p.length;j++)
					{
						b[i].pizza.add(p[j]);
						b[i].setTotal((p[j].calculateCost())+b[i].getTotal());
					}
					h.bill.add(b[i]);
				}
			}
			break;
			case 2:
			{
				h.saveHistory();
				break;
			}

			case 3:
				h.retriveBills();
				break;
			case 4:
				flag=false;
				break;
			default:
				System.out.println("Invalid choice");
				break;
			}
		}
	}
}

package D7;

import java.io.DataOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;

public class History
{
	ArrayList<Bill> bill=new ArrayList<Bill>();
	
	public void saveHistory() 
	{
		File f=new File("bills.dat");
		if(!f.exists())
		{
			try
			{
				f.createNewFile();
			}
			catch (IOException e)
			{
				e.printStackTrace();
			}
		}
		else
		{
			try
			{
				FileOutputStream fos=new FileOutputStream(f,true);
				DataOutputStream dos=new DataOutputStream(fos);
				dos.writeBytes(bill.toString());
				dos.close();
				fos.close();
			}
			catch (IOException e)
			{
				e.printStackTrace();
			}
		}
	}
	
	public void retriveBills() 
	{
		File f=new File("bills.dat");
		try 
		{
			FileInputStream fis=new FileInputStream(f);
			int ch;
			while((ch=fis.read())!=-1)
			{
				System.out.print((char)ch);
			}
		}
		catch (FileNotFoundException e) 
		{
			e.printStackTrace();
		} 
		catch (IOException e)
		{
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	@Override
	public String toString() {
		return "History [bill=" + bill + "]";
	}
}

package Q2D3;

import java.util.Date;

public class Reception
{

	@SuppressWarnings("deprecation")
	public static void main(String[] args)
	{
		Date d=new Date();
		d.setDate(26);
		d.setMonth(12-1);
		d.setYear(2015-1900);
		Order o=new Order(7,d,269,"Mkhitaryan","Armenia",3);
		if(o.delivery())
		{
			System.out.println("Order will be delivered");
		}

	}

}

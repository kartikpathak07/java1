package D3;

public abstract class Pizza
{
	String type;
	String name;
	String size;
	String toppings;
	float timeForPreparation;
	int costOfPizza;

	public Pizza(String type, String name, String size, String toppings)
	{
		if((type.equalsIgnoreCase("veg"))||(type.equalsIgnoreCase("nonveg")))
		{
			this.type = type;
			this.name = name;
			if((size.equalsIgnoreCase("small"))||(size.equalsIgnoreCase("medium")))
			{
				this.size = size;
				this.toppings = toppings;
				if(name.equalsIgnoreCase("Italian"))
				{
					this.timeForPreparation = 10f;
				}
				else if(name.equalsIgnoreCase("Mexican"))
				{
					this.timeForPreparation = 15f;
				}
				this.costOfPizza = calculateCost();
			}
			else
			{
				System.out.println("Only small and medium size pizzas are available");
			}
		}
		else
		{
			System.out.println("Only Veg and Non-Veg type is allowed");
		}
	}
	
	abstract int calculateCost();

}

package D6;

public class MexicanPizza extends Pizza
{

	public MexicanPizza(String type, String name, String size, String toppings)
	{
		super(type, name, size, toppings);
	}

	@Override
	int calculateCost()
	{
		if(type.equalsIgnoreCase("veg"))
		{
			if(size.equalsIgnoreCase("small"))
			{
				if(toppings.equalsIgnoreCase("no"))
				{
					return 300;
				}
				else
				{
					return 330;
				}
			}
			else if(size.equalsIgnoreCase("medium"))
			{
				if(toppings.equalsIgnoreCase("no"))
				{
					return 450;
				}
				else
				{
					return 480;
				}
			}
			else
				return 0;
		}
		else if(type.equalsIgnoreCase("nonveg"))
		{
			if(size.equalsIgnoreCase("small"))
			{
				if(toppings.equalsIgnoreCase("no"))
				{
					return 370;
				}
				else
				{
					return 400;
				}
			}
			else if(size.equalsIgnoreCase("medium"))
			{
				if(toppings.equalsIgnoreCase("no"))
				{
					return 520;
				}
				else
				{
					return 550;
				}
			}
			else
				return 0;
		}
		else
		return 0;
	}
	
	@Override
	public String toString()
	{
		return "Mexican pizza details are : "+type+" "+name+" pizza with "+toppings+" toppings which takes "
	+timeForPreparation+" min for preparation and costing "+costOfPizza+"\n";
	}
	
}

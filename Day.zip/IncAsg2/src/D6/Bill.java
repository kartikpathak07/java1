package D6;

import java.util.Date;
import java.util.Vector;

public class Bill 
{
	int billNo;
	String custName;
	Date date;		
	int total;	
	Vector<Pizza> pizza=new Vector<Pizza>();
	
	public int getBillNo() 
	{
		return billNo;
	}
	
	public String getCustName() 
	{
		return custName;
	}
	
	public Date getDate() 
	{
		return date;
	}
	
	public int getTotal()
	{
		return total;
	}
	
	public void setBillNo(int billNo)
	{
		this.billNo = billNo;
	}
	
	public void setCustName(String custName)
	{
		this.custName = custName;
	}
	
	public void setDate(Date date) 
	{
		this.date = date;
	}
	
	public void setTotal(int total)
	{
		this.total = total;
	}

	@Override
	public String toString() {
		return "Bill No : " + billNo + "\nCustomer Name " + custName + "\ndate : "
				+ date + "\nTotal : " + total + "\npizza=" + pizza;
	}
}

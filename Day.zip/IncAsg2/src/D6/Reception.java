package D6;

import java.util.Date;
import java.util.Scanner;
import java.util.Vector;

public class Reception 
{

	@SuppressWarnings({ "deprecation", "unchecked" })
	public static void main(String[] args)
	{
		Scanner sc=new Scanner(System.in);
		int billno=0;
		Date d=new Date();
		d.setDate(27);
		d.setMonth(4-1);
		d.setYear(2017-1900);
		System.out.print("Enter the number of orders : ");
		int n=sc.nextInt();
		Pizza p[]=new Pizza[n];
		for (int i=0;i<p.length;i++)
		{
			System.out.print("Enter the Italian/Mexican pizza : ");
			String name=sc.next();
			if(name.equalsIgnoreCase("Italian"))
			{
				System.out.print("Enter veg/nonveg pizza : ");
				String type=sc.next();
				System.out.print("Enter size of pizza : ");
				String size=sc.next();
				System.out.print("Enter toppings : ");
				String toppings=sc.next();
				p[i]=new ItalianPizza(type, name, size, toppings);
			}
			else if(name.equalsIgnoreCase("Mexican"))
			{
				System.out.print("Enter veg/nonveg pizza : ");
				String type=sc.next();
				System.out.print("Enter size of pizza : ");
				String size=sc.next();
				System.out.print("Enter toppings : ");
				String toppings=sc.next();
				p[i]=new MexicanPizza(type, name, size, toppings);
			}
			else
			{
				System.out.println("Inavlid name");
			}
		}
		for (int i=0;i<p.length;i++) 
		{
			if(p[i].timeForPreparation>0)
			{
			System.out.println(p[i].toString());
			}
		}
		
		Bill b=new Bill();
		b.setBillNo(billno+1);
		System.out.println("Enter name of customer : ");
		b.setCustName(sc.next());
		b.setDate(d);
		b.setTotal(0);
		for (int i=0;i<p.length;i++)
		{
			b.pizza.add(p[i]);
			b.setTotal((p[i].calculateCost())+b.getTotal());
		}
		System.out.println(b);
	}

}

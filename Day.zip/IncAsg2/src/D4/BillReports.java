package D4;

import java.util.Arrays;

public class BillReports
{
	private Bill bill[];

	public Bill[] getBill() 
	{
		return bill;
	}

	public void setBill(Bill[] bill) 
	{
		this.bill = bill;
	}
	
	boolean  updateBill(int billNo, int newTotal)
	{
		for(int i=0;i<bill.length;i++)
		{
			if(bill[i].getBillNo()==billNo)
			{
				bill[i].setTotal(newTotal);
				return true;
			}
		}
		return false;
	}
	
	Bill  searchBill(int billNo) throws BillNotFoundException
	{
		for(int i=0;i<bill.length;i++)
		{
			if(bill[i].getBillNo()==billNo)
			{
				return bill[i];
			}
		}
		throw new BillNotFoundException("Bill cannot be found");
	}

	@Override
	public String toString() {
		return "BillReports bill= " + Arrays.toString(bill);
	}
}

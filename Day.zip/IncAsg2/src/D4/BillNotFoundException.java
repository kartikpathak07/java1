package D4;

@SuppressWarnings("serial")
public class BillNotFoundException extends Exception 
{
	public BillNotFoundException(String message) 
	{
		super(message);
	}
}

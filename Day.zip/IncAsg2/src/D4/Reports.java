package D4;

import java.util.Date;
import java.util.Scanner;

public class Reports 
{

	@SuppressWarnings("deprecation")
	public static void main(String[] args)
	{
		// TODO Auto-generated method stub
		Scanner sc=new Scanner(System.in);
		BillReports br=new BillReports();
		Date d=new Date();
		d.setDate(27);
		d.setMonth(4-1);
		d.setYear(2017-1900);
		System.out.print("Enter number of bills to be entered : ");
		int n=sc.nextInt();
		Bill b[]=new Bill[n];
		for (int i=0;i<b.length;i++) 
		{
			b[i]=new Bill();
			System.out.print("Enter bill number : ");
			b[i].setBillNo(sc.nextInt());
			System.out.print("Enter customer name : ");
			b[i].setCustName(sc.next());
			b[i].setDate(d);
			String[] items=new String[2];
			for (int j=0;j<items.length;j++) 
			{
				System.out.print("Enter "+(j+1)+" item : ");
				items[j]=sc.next();
			}
			b[i].setItems(items);
			System.out.print("Enter total : ");
			b[i].setTotal(sc.nextInt());
		}
		br.setBill(b);
		
		Bill[] bd1=br.getBill();
		for (int i=0;i<bd1.length;i++) 
		{
			System.out.println(i+"  "+bd1[i]);
		}
		
		System.out.print("Enter bill no to be updated : ");
		int billno=sc.nextInt();
		System.out.print("Enter new total :");
		int newtotal=sc.nextInt();
		if(br.updateBill(billno, newtotal))
		{
			System.out.println("Bill updated successfully!!");
			Bill[] bd2=br.getBill();
			for (int i=0;i<bd2.length;i++) 
			{
				System.out.println(i+"  "+bd2[i]);
			}
		}
		
		System.out.print("Enter bill no to be searched : ");
		int bno=sc.nextInt();
		try 
		{
			Bill b1=br.searchBill(bno);
			System.out.println(b1);
		} catch (BillNotFoundException e) 
		{
			System.out.println(e.getMessage());
		}
		

	}

}

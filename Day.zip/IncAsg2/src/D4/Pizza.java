package D4;

public abstract class Pizza
{
	String type;
	String name;
	String size;
	String toppings;
	float timeForPreparation;
	int costOfPizza;

	public Pizza(String type, String name, String size, String toppings) throws InvalidPizzaTypeException, InvalidPizzaSizeException
	{
		if((type.equalsIgnoreCase("veg"))||(type.equalsIgnoreCase("nonveg")))
		{
			this.type = type;
		}
		else
		{
			throw new InvalidPizzaTypeException("Only veg and nonveg pizza type available");
		}
		this.name = name;
		if((size.equalsIgnoreCase("small"))||(size.equalsIgnoreCase("medium")))
		{
			this.size = size;
		}
		else
		{
			throw new InvalidPizzaSizeException("Only small and medium size pizzas are available");
		}
		this.toppings = toppings;
		if(name.equalsIgnoreCase("Italian"))
		{
			this.timeForPreparation = 10f;
		}
		else if(name.equalsIgnoreCase("Mexican"))
		{
			this.timeForPreparation = 15f;
		}
		this.costOfPizza = calculateCost();
	}
	abstract int calculateCost();
}

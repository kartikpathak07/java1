package D5;

@SuppressWarnings("serial")
public class InvalidPizzaTypeException extends Exception
{
	public InvalidPizzaTypeException(String message)
	{
		super(message);
	}
}

package D5;

public class Pizza
{
	String type;
	String name;
	String size;
	String toppings;
	float timeForPreparation;	
	//int costOfPizza;

	public Pizza(String type, String name, String size, String toppings,
			float timeForPreparation) {
		super();
		this.type = type;
		this.name = name;
		this.size = size;
		this.toppings = toppings;
		this.timeForPreparation = timeForPreparation;
	}

	public void placeOrder() {
		
		
	}
	
	public void cookingInProcess() {
		
	}
	
	
	public Pizza(String type, String name, String size, String toppings) throws InvalidPizzaTypeException, InvalidPizzaSizeException
	{
		if((type.equalsIgnoreCase("veg"))||(type.equalsIgnoreCase("nonveg")))
		{
			this.type = type;

		}
		else
		{
			throw new InvalidPizzaTypeException("Only veg and nonveg pizza type available");
		}
		this.name = name;
		if((size.equalsIgnoreCase("small"))||(size.equalsIgnoreCase("medium")))
		{
			this.size = size;
		}
		else
		{
			throw new InvalidPizzaSizeException("Only small and medium size pizzas are available");
		}
		this.toppings = toppings;
		if(name.equalsIgnoreCase("Italian"))
		{
			this.timeForPreparation = 10f;
		}
		else if(name.equalsIgnoreCase("Mexican"))
		{
			this.timeForPreparation = 15f;
		}
		//this.costOfPizza = calculateCost();
	}
	

	@Override
	synchronized public String toString() 
	{
		return "Pizza [type=" + type + ", name=" + name + ", size=" + size
				+ ", toppings=" + toppings + ", timeForPreparation="
				+ timeForPreparation + "]";
	}
	
	
	//abstract int calculateCost();
}

package D5;

@SuppressWarnings("serial")
public class InvalidPizzaSizeException extends Exception
{
	public InvalidPizzaSizeException(String message)
	{
		super(message);
	}
}

package D5;

public class CookThread extends Thread
{
//	String name;
	Pizza pizza;
	boolean b=false;

	public CookThread(/*String name,*/ Pizza pizza)
	{
//		this.name = name;
		this.pizza = pizza;
		start();
	}

	@Override
	public void run()
	{
		System.out.println("Cooking "+pizza);
	}
	
}

package D5;

public class WaiterThread extends Thread
{
//	String name;
	Pizza pizza;

	
	public WaiterThread(/*String name,*/ Pizza pizza) 
	{
//		this.name = name;
		this.pizza = pizza;
		start();
	}


	@Override
	public void run()
	{
		pizza.cookingInProcess();
		System.out.println("Serving "+pizza);
	}
}

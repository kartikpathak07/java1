package D5;

public class PizzaHut {

	public static void main(String[] args)
	{
		try 
		{
			Pizza p=new Pizza("veg", "Italian", "small", "olives");
			WaiterThread wt=new WaiterThread(p);
			CookThread ct=new CookThread(p);
			
			
		} 
		catch (InvalidPizzaTypeException e) 
		{
			System.out.println(e.getMessage());
		} 
		catch (InvalidPizzaSizeException e) 
		{
			System.out.println(e.getMessage());
		}

		

	}

}

package Q2;

import java.util.Scanner;

public class PizzaHut {

	public static void main(String[] args) 
	{
		Scanner sc=new Scanner(System.in);
		System.out.print("Enter the number of orders : ");
		int n=sc.nextInt();
		Pizza p[]=new Pizza[n];
		for (int i=0;i<p.length;i++) 
		{
			System.out.print("Enter the Italian/Mexican pizza : ");
			String name=sc.next();
			if(name.equalsIgnoreCase("Italian"))
			{
				System.out.print("Enter veg/nonveg pizza : ");
				String type=sc.next();
				System.out.print("Enter toppings : ");
				String toppings=sc.next();
				p[i]=new ItalianPizza(type,toppings,name);
			}
			else if(name.equalsIgnoreCase("Mexican"))
			{
				System.out.print("Enter veg/nonveg pizza : ");
				String type=sc.next();
				System.out.print("Enter toppings : ");
				String toppings=sc.next();
				p[i]=new MexicanPizza(type,toppings,name);
			}
			else
			{
				System.out.println("Inavlid name");
			}
		}
		for (int i=0;i<p.length;i++) 
		{
			if(p[i].timeForPreparation>0)
			{
			System.out.println(p[i].toString());
			}
		}
	}
}

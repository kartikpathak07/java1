package Q2;

public class MexicanPizza extends Pizza
{

	public MexicanPizza(String type, String toppings, String name)
	{
		super(type, toppings, name);
	}

	@Override
	public String toString()
	{
		return "Mexican pizza details are : "+type+" "+name+" pizza with "+toppings+" toppings which takes "
	+timeForPreparation+" min for preparation";
	}
	
	
}

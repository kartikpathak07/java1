package Q2;

public class Pizza 
{
	String type;
	String toppings;
	String name;
	float timeForPreparation;
	
	public Pizza(String type, String toppings, String name) 
	{
		if((type.equalsIgnoreCase("veg"))||(type.equalsIgnoreCase("nonveg")))
		{
			this.type = type;
			this.toppings = toppings;
			this.name = name;
			if(name.equalsIgnoreCase("Italian"))
			{
				this.timeForPreparation = 10f;
			}
			else if(name.equalsIgnoreCase("Mexican"))
			{
				this.timeForPreparation = 15f;
			}
		}
		else
		{
			System.out.println("Invalid type");
		}
	}
	
	@Override
	public String toString() 
	{
		return "Pizza type : " + type + "with toppings : " + toppings + " having name="+ name + " and Time For Preparation is"
	+ timeForPreparation;
	}
	
}

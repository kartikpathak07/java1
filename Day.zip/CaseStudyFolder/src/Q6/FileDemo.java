package Q6;

import java.io.BufferedReader;
import java.io.DataInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.Reader;
import java.util.ArrayList;
import java.util.StringTokenizer;

public class FileDemo
{
	static ArrayList<String> al=new ArrayList<String>();

	static
	{
		File f=new File("input.dat");
		if(f.exists())
		{
			try 
			{
				FileReader fio =new FileReader(f);
				BufferedReader br=new BufferedReader(fio);
				FileWriter fos=new FileWriter("output.dat");
				String ch;
				while((ch=br.readLine())!=null)
				{
					StringTokenizer st=new StringTokenizer(ch,"\n");
					while(st.hasMoreTokens())
					{
						al.add(st.nextToken());
						fos.write(ch);
					}	
				}
			}
			catch (FileNotFoundException e) 
			{
				e.printStackTrace();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
	}

	public static void main(String[] args)
	{
		int n=al.size();
		for(int i=0;i<n;i++)
		{
			System.out.println((i+1)+"   "+al.get(i));
		}
	}
}

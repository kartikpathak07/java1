package Q7;

import java.io.DataOutputStream;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.Hashtable;

public class MyShopping
{
	private Hashtable<Customer,Order> hs=new Hashtable<Customer, Order>();
	Order o;
	Customer c;

	public MyShopping(Hashtable<Customer, Order> hs) 
	{
		this.hs = hs;
	}

	public void getRecord(String filename) 
	{
		FileInputStream fis=null;
		try
		{
			fis=new FileInputStream(filename);
			int ch;
			while((ch=fis.read())!=-1)
			{
				System.out.print((char)ch);
			}
		}
		catch (FileNotFoundException e)
		{
			e.printStackTrace();
		
		} catch (IOException e) 
		{
			e.printStackTrace();
		}
		finally
		{
			try 
			{
				fis.close();
			} 
			catch (IOException e) 
			{
				e.printStackTrace();
			}
		}
	}

	public void setRecord(String filename) 
	{
		FileOutputStream fos=null;
		DataOutputStream dos=null;
		try 
		{
			fos=new FileOutputStream(filename);
			dos=new DataOutputStream(fos);
			dos.writeBytes(hs.toString());
		}
		catch (FileNotFoundException e) 
		{
			e.printStackTrace();
		} 
		catch (IOException e) 
		{
			e.printStackTrace();
		}
		finally
		{
			try 
			{
				dos.close();
				fos.close();
			}
			catch (IOException e) 
			{
				e.printStackTrace();
			}
			
		}
	}

	@Override
	public String toString() 
	{
		return "MyShopping is \n " + hs + " Order : " + o + "\n Customer : " + c;
	}
}

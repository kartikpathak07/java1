package Q7;

public class Customer 
{
	private int custNo;
	private String custName;
	
	public Customer(int custNo, String custName) 
	{
		this.custNo = custNo;
		this.custName = custName;
	}

	public int getCustNo() 
	{
		return custNo;
	}

	public String getCustName()
	{
		return custName;
	}

	@Override
	public String toString()
	{
		return "Customer No : " + custNo + " Customer Name : " + custName+"\n";
	}
}

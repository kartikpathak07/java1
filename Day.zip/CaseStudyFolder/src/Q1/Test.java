package Q1;

import java.io.DataOutputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.Scanner;

public class Test 
{

	public static void main(String[] args) 
	{
		Scanner sc=new Scanner(System.in);
		System.out.print("Enter ID : ");
		int id=sc.nextInt();
		System.out.print("Enter name : ");
		String name=sc.next();
		System.out.print("Enter salary : ");
		int sal=sc.nextInt();
		Employee e=new Employee(id, name, sal);
		try
		{
			FileOutputStream fos=new FileOutputStream("store.txt");
			DataOutputStream dos=new DataOutputStream(fos);
			dos.writeBytes(e.toString());
			System.out.println("Data inserted successfully");
		} 
		catch (FileNotFoundException e1)
		{
			e1.printStackTrace();
		} 
		catch (IOException e1) 
		{
			e1.printStackTrace();
		}
	}
}

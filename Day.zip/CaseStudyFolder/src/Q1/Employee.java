package Q1;

public class Employee
{
	private  int empId;
	private  String  empName;
	private int empSalary;
	
	public Employee(int empId, String empName, int empSalary)
	{
		this.empId = empId;
		this.empName = empName;
		this.empSalary = empSalary;
	}

	@Override
	public String toString() 
	{
		return "Id is : "+empId+"\nName is : "+empName+"\nSalary is : "+empSalary;
	}
}

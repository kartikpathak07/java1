package InterfaceDemo;

import java.util.Scanner;

public class Doctor implements MyInterface
{
	Scanner sc=new Scanner(System.in);
	private String degree;
	private String name;
	
	@Override
	public void getData()
	{
		// TODO Auto-generated method stub
		System.out.println("Enter the degree : ");
		this.degree=sc.next();
		System.out.println("Enter the name : ");
		this.name=sc.next();
	}
	
	@Override
	public void putData() 
	{
		// TODO Auto-generated method stub
		System.out.println("Degree is "+this.degree);
		System.out.println("Name is "+this.name);
		
	}
}

package D3;

public interface CardSearchable
{
	Card searchCard(String sub);
}

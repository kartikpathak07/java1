
public class StringDemo 
{

	public static void main(String[] args) 
	{
		// TODO Auto-generated method stub
		
		//String
		String s="Cristiano";
		System.out.println(s.hashCode());
		s=s.concat(" Ronaldo");
		System.out.println(s.hashCode());
		
		//String Buffer
		StringBuffer sb=new StringBuffer("Cristiano");
		System.out.println(sb.hashCode());
		sb=sb.append(" Ronaldo");
		System.out.println(sb.hashCode());
		
		//String Builder
		StringBuilder sbd=new StringBuilder("Cristaino");
		System.out.println(sbd.hashCode());
		sbd=sbd.append(" Ronaldo");
		System.out.println(sbd.hashCode());
	}

}

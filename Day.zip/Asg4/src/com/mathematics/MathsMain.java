package com.mathematics;

public class MathsMain 
{

	public static void main(String[] args) 
	{
		// TODO Auto-generated method stub
		MathDetails m=new MathDetails();
		m.sine();
		m.cosine();
		m.tangent();
		m.asine();
		m.acosine();
		m.atangent();
		m.max();
		m.min();
		m.sqrt();
		m.cbrt();
	}

}

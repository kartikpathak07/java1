package com.mathematics;

public interface Maths
{
	void sine();
	void cosine();
	void tangent();
	void asine();
	void acosine();
	void atangent();
	void max();
	void min();
	void sqrt();
	void cbrt();
}

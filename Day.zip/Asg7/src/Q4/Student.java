package Q4;

@SuppressWarnings("rawtypes")
public class Student implements Comparable
{
	private int rollNo;
	private String name;

	public Student(int rollNo, String name) 
	{
		this.rollNo = rollNo;
		this.name = name;
	}

	@Override
	public int compareTo(Object obj) 
	{
		Student s=(Student) obj;
		int var=this.name.compareTo(s.name);
		if(var<0)
			return -1;
		else if(var>0)
			return 1;
		else
			return 0;
	}

	@Override
	public String toString() {
		return "\nrollNo=" + rollNo + ", name=" + name ;
	}
	
	/*	public int getRollNo() {
		return rollNo;
	}

	public void setRollNo(int rollNo) {
		this.rollNo = rollNo;
	}*/

	/*public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}*/

	/*@Override
	public int compareTo(Object obj) {
	Student s=(Student) obj;
	if(this.rollNo < s.rollNo)
		return -1;
	else if (this.rollNo > s.rollNo)
		return 1;
	else
		return 0;
	}*/
}
package Q3;

import java.util.Iterator;
import java.util.TreeSet;

public class TestTreeSet 
{

	public static void main(String[] args) 
	{
		// TODO Auto-generated method stub
		TreeSet<String> product=new TreeSet<String>();
		
		//adding
		product.add("Rooney");
		product.add("Ibrahimovic");
		product.add("Mkhitaryan");
		product.add("Pogba");
		product.add("Mata");
		
		//displaying
		System.out.println(product);
		
		//displaying using iterator
		Iterator<String> i=product.iterator();
		while(i.hasNext())
		{
			System.out.println(i.next());
		}
		
		//printing only 1st value
		System.out.println(product.first());
		
		//printing only last value
		System.out.println(product.last());
		
		//size of tree set
		System.out.println(product.size());
		
		//deleteing a value
		product.remove("Mata");
		
		//size
		System.out.println(product.size());
		
		
		
	}

}

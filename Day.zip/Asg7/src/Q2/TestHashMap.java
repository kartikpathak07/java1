package Q2;

public class TestHashMap 
{

	public static void main(String[] args) 
	{
		// TODO Auto-generated method stub
		Student s=new Student();
		s.setNames("MU101", "Rooney");
		s.setNames("MU102", "Pogba");
		s.setNames("MU103", "Ibrahimovic");
		s.setNames("MU104", "De Gea");
		s.setNames("MU105", "Mkhitaryan");
		s.setNames("MU106", "Mata");
		s.printNames();
		s.printSize();
		s.printNamesKeySet();
		s.getName("MU103");
		s.remove("MU106");
		s.printNamesKeySet();
		s.printSize();
	}

}

package Q1;

import java.util.ArrayList;


public class Student
{
	private ArrayList<String> names=new ArrayList<String>();
	
	public void printName() 
	{
		System.out.println(names);
	}

	public void setName(String name)
	{
		names.add(name);
	}
	
	public void searchName(String name)
	{
			int n=names.indexOf(name);
			System.out.println("Index of student "+name+" is : "+n);
	}
	
	public void searchName(int index)
	{
		String name=names.get(index);
		System.out.println("Name of student at index "+index+" is "+name);
	}
	
	public void removeName(String stuName)
	{
		names.remove(stuName);
	}
}

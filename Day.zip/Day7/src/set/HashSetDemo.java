package set;

import java.util.HashSet;

import List.Emp;

public class HashSetDemo 
{
	@SuppressWarnings({ "rawtypes", "unchecked" })
	public static void main(String[] args) 
	{
		HashSet hs=new HashSet();
		hs.add(true);
		hs.add(7);
		hs.add("Pogba");
		hs.add('K');
		hs.add(new Emp(7, "Rooney"));
		System.out.println(hs);
	}

}

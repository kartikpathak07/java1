package List;

import java.util.Vector;

public class VectorDemo 
{
	@SuppressWarnings({ "rawtypes", "unchecked" })
	public static void main(String[] args) 
	{
		Vector v= new Vector(5,10);
		v.add(7);
		v.add('K');
		v.add("Ronaldo");
		v.add(true);
		v.add(7.7);
		System.out.println(v.capacity());
	}

}

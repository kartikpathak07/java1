package List;

import java.util.ArrayList;
import java.util.Iterator;

public class ArrayListDemo
{
	@SuppressWarnings({ "unchecked", "rawtypes" })
	public static void main(String[] args) 
	{
		ArrayList al=new ArrayList();
		al.add(7);
		al.add('K');
		al.add("Ronaldo");
		al.add(true);
		al.add(7.7);
		al.remove(7.7);
		System.out.println(al);
		al.add(7.7);
		al.add(new Emp(7,"Tevez"));
		/*System.out.println(al.size());
		System.out.println(al);
		System.out.println(al.get(4));
		
		//how to display
		//1. 
		System.out.println(al);
		
		//2.
		for (int i = 0; i < al.size(); i++) 
		{
			System.out.println(al.get(i));
		}*/
		
		//3.
		Iterator i=al.iterator();
		while (i.hasNext()) 
		{
			System.out.println(i.next());
		}
		
		
	}
}

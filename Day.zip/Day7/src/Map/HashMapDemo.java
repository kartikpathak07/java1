package Map;

import java.util.Collections;
import java.util.Enumeration;
import java.util.HashMap;

public class HashMapDemo 
{

	@SuppressWarnings("rawtypes")
	public static void main(String[] args) 
	{
		// TODO Auto-generated method stub
		HashMap<Integer, String> hm=new HashMap<Integer, String>();
		hm.put(1, "Rooney");
		hm.put(2, "Mkhitaryan");
		
		//1
		//System.out.println(hm);
		
		//2
		/*for (int i = 1; i <= hm.size(); i++) 
		{
			System.out.println(hm.get(i));
		}*/
		
		//3
		Enumeration e = Collections.enumeration(hm.values());
		//Enumeration e=(Enumeration) hm.entrySet();
		while(e.hasMoreElements())
		{
			System.out.println(e.nextElement());
		}
	}

}

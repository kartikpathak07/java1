
public class Q3 {

	public static void main(String[] args) 
	{
		// TODO Auto-generated method stub
		int n1=Integer.parseInt(args[0]);
		int n2=Integer.parseInt(args[1]);
		char ch=args[2].charAt(1);
		float res=0;
		switch (ch)
		{
		case '+':
			res=n1+n2;
			break;
		case '-':
			res=n1-n2;
			break;
		case '*':
			res=n1*n2;
			break;
		case '/':
			res=n1/n2;
			break;
		default:
			System.out.println("Invalid operator");
		}
		System.out.println("result is "+res);
		
	}

}


public class Q1 
{

	public static void main(String[] args) 
	{
		// TODO Auto-generated method stub
		int n=Integer.parseInt(args[0]);
		for (int i=2; i<=n;i=i+2) 
		{
			System.out.print(i+"\t");
		}

	}

}

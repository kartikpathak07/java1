
public class Q2 
{

	public static void main(String[] args) 
	{
		// TODO Auto-generated method stub
		int arr[]=new int[args.length];
		int sum=0, avg=0;
		for (int i=0;i<args.length;i++)
		{
			arr[i]=Integer.parseInt(args[i]);
		}
		for (int i=0;i<arr.length;i++)
		{
			sum=sum+arr[i];
		}
		avg=(sum/arr.length);
		System.out.println("Sum of numbers is : "+sum);
		System.out.println("Avg of numbers is : "+avg);
		System.out.println("Numbers less than "+avg+" are ");
		for (int i=0;i<arr.length;i++)
		{
			if(arr[i]<avg)
			{
				System.out.print("\t"+arr[i]);
			}
		}
	}

}

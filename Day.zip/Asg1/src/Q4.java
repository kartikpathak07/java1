import java.util.Scanner;


public class Q4 
{

	public static void main(String[] args) 
	{
		// TODO Auto-generated method stub
		Scanner sc=new Scanner(System.in);
		int arr[]={7,18,27,32,44};
		System.out.println("Enter a number from 1 to 50");
		int num=sc.nextInt();
		if(num<0 || num>50)
		{
			System.out.println("Number out of range");
		}
		else
		{
			for(int i=0;i<arr.length;i++)
			{
				if(num==arr[i])
				{
					System.out.println("Bingo!!!!");
					break;
				}
				else
				{
					System.out.println("Number not present in array");
				}
			}
			
		}
		

	}

}

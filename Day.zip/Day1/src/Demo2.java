public class Demo2 
{

	public static void main(String[] args) 
	{
		// TODO Auto-generated method stub
		int num1=4, num2=3, sum;
		sum=num1+num2;
		System.out.println("Addition of "+num1+" + "+num2+" = "+sum);
		

	}

}

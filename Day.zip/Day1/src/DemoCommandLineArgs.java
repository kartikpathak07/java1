
public class DemoCommandLineArgs
{
	//args is reference to an array of string type
	//values passed to main method are called as command line arguments
	public static void main(String[] args)
	{
		// TODO Auto-generated method stub
		int sum=0;
		int n1=Integer.parseInt(args[0]);
		int n2=Integer.parseInt(args[1]);
		sum = n1 + n2;
		System.out.println("Sum is "+sum);
		System.out.println("Number 1 : "+args[0]);
		System.out.println("Number 2 : "+args[1]);
		System.out.println("No of args passed "+args.length);
	}

}

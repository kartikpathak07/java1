public class Demo1 
{
	public static void main(String[] args) 
	{
		// TODO Auto-generated method stub
		System.out.println("Hello World!!!");
		int i=7;
		System.out.println("i is "+i);
		char ch='K';
		System.out.println("ch is "+ch);
		float f=7.7f;
		System.out.println("f is "+f);
		double d=77.7;
		System.out.println("d is "+d);
		boolean b=true;
		System.out.println("b is "+b);
		String str="CR7";
		System.out.println("str is "+str);
		String str1=new String("CR7");
		System.out.println("str1 is "+str1);
	}

}

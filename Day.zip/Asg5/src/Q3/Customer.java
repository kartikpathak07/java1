package Q3;

public class Customer 
{
	private String custNo;
	private String custName;
	private String category;

	public String getCustNo() {
		return custNo;
	}
	public void setCustNo(String custNo) throws CustomerException 
	{
		if(custNo.startsWith("C")||custNo.startsWith("c"))
		{
			if(custNo.startsWith("c"))
			{
				String cno=custNo;
				String c=cno.replace("c", "C");
				this.custNo = c;
			}
			else
			{
				this.custNo = custNo;
			}
		}
		else
		{
			throw new CustomerException("Customer ID must start with C");
		}
	}
	public String getCustName() {
		return custName;
	}
	public void setCustName(String custName) throws CustomerException 
	{
		if(custName.length()>3)
		{
			this.custName = custName;
		}
		else
		{
			throw new CustomerException("Name should be more than 4 characters");
		}
	}
	public String getCategory() {
		return category;
	}
	public void setCategory(String category) throws CustomerException
	{
		if(category.equalsIgnoreCase("Platinum")||category.equalsIgnoreCase("Gold")||category.equalsIgnoreCase("Silver"))
		{
			this.category = category;
		}
		else
		{
			throw new CustomerException("Category can only be Platinum, Gold or Silver");
		}
	}
	@Override
	public String toString() {
		return "Customer [custNo=" + custNo + ", custName=" + custName
				+ ", category=" + category + "]";
	}
}

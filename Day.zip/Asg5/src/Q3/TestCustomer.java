package Q3;

import java.util.Scanner;

public class TestCustomer 
{

	public static void main(String[] args) 
	{
		// TODO Auto-generated method stub
		Scanner sc=new Scanner(System.in);
		Customer c=new Customer();
		boolean flag=true;

		try
		{
			System.out.println("Enter customer number");
			c.setCustNo(sc.nextLine());
		} 
		catch (CustomerException e)
		{
			// TODO Auto-generated catch block
			flag=false;
			System.err.println(e.getMessage());
		}

		try 
		{
			System.out.println("Enter customer name");
			c.setCustName(sc.next());
		} 
		catch (CustomerException e1)
		{
			// TODO Auto-generated catch block
			flag=false;
			System.err.println(e1.getMessage());
		}

		try
		{
			System.out.println("Enter category");
			c.setCategory(sc.next());
		}
		catch (CustomerException e2)
		{
			// TODO Auto-generated catch block
			flag=false;
			System.err.println(e2.getMessage());
		}

		if (flag)
		{
			System.out.println(c);
		}

	}

}

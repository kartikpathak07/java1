package Q7;

public class Account implements AccountInter 
{
	private int accNo;
	private String name;
	private double accBal;
	Account ac;

	public int getAccNo() {
		return accNo;
	}

	@Override
	public void create(int accNo, String name, double accBal) 
	{
		this.accNo=accNo;
		this.name=name;
		this.accBal=accBal;
	}

	@Override
	public double delete(int accNo) 
	{
		if(this.accNo==accNo)
		{
			this.accNo=0;
			this.name=null;
			this.accBal=0;
			return 0;
		}
		else
		{
			return 1;
		}
	}

	@Override
	public void print(int accNo) 
	{
		if(this.accNo>0)
		{
			if(this.accNo==accNo)
			{
				System.out.println("Account No : "+this.accNo+" Name : "+this.name+" Balance : "+this.accBal);
			}
		}
		else
		{
			System.out.println("Account does not exists");
		}
	}
}


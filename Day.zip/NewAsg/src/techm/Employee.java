package techm;

public class Employee
{
	private int empNo;
	private String empName;
	private int empSal;
	
	public Employee() 
	{
		this.empNo = 123;
		this.empName = "Manjiri";
		this.empSal = 25000;
	}

	public int getEmpNo() {
		return empNo;
	}

	public void setEmpNo(int empNo) {
		this.empNo = empNo;
	}

	public String getEmpName() {
		return empName;
	}

	public void setEmpName(String empName) {
		this.empName = empName;
	}

	public int getEmpSal() {
		return empSal;
	}

	public void setEmpSal(int empSal) {
		this.empSal = empSal;
	}

	@Override
	public String toString() 
	{
		return "Employee number : " + empNo + ", employee name : " + empName	+ ", employee salary : " + empSal;
	}
}

package Q4;

public class TestCircle
{

	public static void main(String[] args) 
	{
		// TODO Auto-generated method stub
		Circle c=new Circle();
		double res=c.calArea(7.7);
		System.out.println(res);
		double res1=c.calCircumference(2.7);
		System.out.println(res1);

	}

}

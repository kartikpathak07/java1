package application;

import techm.Employee;

public class EmployeeData 
{

	public static void main(String[] args)
	{
		// TODO Auto-generated method stub
		Employee e=new Employee();
		System.out.println(e);
		Employee e1=new Employee();
		e1.setEmpNo(1021);
		e1.setEmpName("Pogba");
		e1.setEmpSal(35000);
		System.out.println(e1);
		Employee e2=new Employee();
		e2.setEmpNo(2031);
		e2.setEmpName("Rooney");
		e2.setEmpSal(40000);
		System.out.println(e2);

	}

}

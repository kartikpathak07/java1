package com.techm.geometry;

import geometry.shapes.Line;
import geometry.shapes.Point;

public class TestLine {

	public static void main(String[] args) 
	{
		// TODO Auto-generated method stub
		Line l=new Line();
		Point p1=new Point();
		p1.setX(5);
		p1.setY(6);
		Point p2=new Point();
		p2.setX(8);
		p2.setY(9);
		l.setPoint1(p1);
		l.setPoint2(p2);
		l.draw();
		l.scale();
	}

}

package com.application;

import com.tech.Employee;

public class EmployeeData 
{

	public static void main(String[] args)
	{
		// TODO Auto-generated method stub
		Employee e=new Employee();
		System.out.println(e);
		Employee e1=new Employee(1021, "Pogba", 35000);
		System.out.println(e1);
		Employee e2=new Employee(2031, "Rooney", 40000);
		System.out.println(e2);

	}

}

package Q1;

public class TestArithmetic 
{

	public static void main(String[] args) 
	{
		// TODO Auto-generated method stub
		Aritmetic ar=new Aritmetic();
		int a=ar.addition(7,1);
		int b=ar.addition(7,1,3);
		double c=ar.addition(7,2.7);
		double d=ar.addition(7.7,2.7);
		float e=ar.addition(7.7f,2.7f,1.0f);
		System.out.println(a);
		System.out.println(b);
		System.out.println(c);
		System.out.println(d);
		System.out.println(e);

	}

}

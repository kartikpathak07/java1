package Q1;

public class Aritmetic 
{
	public int addition( int firstNo, int secondNo )
	{
		int res=firstNo+secondNo;
		return res;
	}
	
	public int addition( int firstNo, int secondNo, int thridNo )
	{
		int res=firstNo+secondNo+thridNo;
		return res;
	}
	
	public double addition( double firstNo, double secondNo )
	{
		double res=firstNo+secondNo;
		return res;
	}
	
	public double addition( int firstNo, double secondNo )
	{
		double res=firstNo+secondNo;
		return res;
	}
	
	public float addition( float firstNo, float secondNo, float thirdNo )
	{
		float res=firstNo+secondNo+thirdNo;
		return res;
	}
}

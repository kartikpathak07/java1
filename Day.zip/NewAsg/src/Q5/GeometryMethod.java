package Q5;

public interface GeometryMethod extends GeometryConstant
{
	double calArea ( double radius );
	double calCircumference ( double radius );
}

package Q5;

public interface GeometryConstant 
{
	final double PI = 3.142;
}

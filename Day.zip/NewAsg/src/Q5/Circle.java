package Q5;

public class Circle implements GeometryConstant, GeometryMethod 
{

	@Override
	public double calArea(double radius) 
	{
		// TODO Auto-generated method stub
		double res=PI*radius*radius;
		return res;
	}

	@Override
	public double calCircumference(double radius) 
	{
		// TODO Auto-generated method stub
		double res=2*PI*radius;
		return res;
	}

}
